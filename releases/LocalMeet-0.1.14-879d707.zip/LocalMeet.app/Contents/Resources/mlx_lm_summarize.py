#!/usr/bin/env python3
import argparse
import re

from huggingface_hub import snapshot_download


def build_prompt(tokenizer, title: str, transcript: str) -> str:
    messages = [
        {
            "role": "system",
            "content": (
                "You are a careful meeting assistant. Produce concise, useful notes. "
                "Do not invent owners, dates, or decisions."
            ),
        },
        {
            "role": "user",
            "content": (
                f"Meeting title: {title}\n\n"
                "Summarize this transcript with these sections:\n"
                "- Overview\n"
                "- Decisions\n"
                "- Action items with owners if stated\n"
                "- Open questions\n\n"
                f"Transcript:\n{transcript}"
            ),
        },
    ]

    if hasattr(tokenizer, "apply_chat_template"):
        try:
            return tokenizer.apply_chat_template(
                messages,
                tokenize=False,
                add_generation_prompt=True,
                enable_thinking=False,
            )
        except TypeError:
            return tokenizer.apply_chat_template(
                messages,
                tokenize=False,
                add_generation_prompt=True,
            )

    return "\n\n".join(message["content"] for message in messages)


def clean_response(response: str) -> str:
    response = re.sub(r"(?is)<think>.*?</think>", "", response)
    response = re.sub(r"(?is)^\s*<think>.*$", "", response)
    response = re.sub(r"(?is)^\s*</think>\s*", "", response)
    return response.strip()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", required=True)
    parser.add_argument("--cache-dir", required=True)
    parser.add_argument("--title", required=True)
    parser.add_argument("--transcript-file", required=True)
    parser.add_argument("--max-tokens", type=int, default=900)
    args = parser.parse_args()

    with open(args.transcript_file, "r", encoding="utf-8") as handle:
        transcript = handle.read()

    snapshot_path = snapshot_download(
        repo_id=args.model,
        cache_dir=args.cache_dir,
        local_files_only=True,
    )

    from mlx_lm import generate, load

    model, tokenizer = load(snapshot_path)
    prompt = build_prompt(tokenizer, args.title, transcript)
    response = generate(
        model,
        tokenizer,
        prompt=prompt,
        max_tokens=args.max_tokens,
        verbose=False,
    )

    print(clean_response(response))


if __name__ == "__main__":
    main()
