#!/usr/bin/env python3
import argparse

from huggingface_hub import snapshot_download


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", required=True)
    parser.add_argument("--cache-dir", required=True)
    args = parser.parse_args()

    snapshot_path = snapshot_download(repo_id=args.model, cache_dir=args.cache_dir)

    from mlx_lm import load

    load(snapshot_path, lazy=True)
    print(f"ready: {args.model}")


if __name__ == "__main__":
    main()
